'use strict';
window.AgentProvI18n = (() => { const data = {"locale":"en","messages":null};
 return Object.freeze({
  locale: data.locale,
  t: (source) => Object.prototype.hasOwnProperty.call(data.messages || {}, source) ? data.messages[source] : source,
  url: (value, locale = data.locale) => {
   const result = new URL(value, location.href);
   if (result.origin === location.origin) result.searchParams.set('lang', locale);
   return result.href;
  }
 });
})();
