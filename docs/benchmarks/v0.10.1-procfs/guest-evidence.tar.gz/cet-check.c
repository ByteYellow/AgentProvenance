#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
__attribute__((noinline)) int nested(int x) { volatile int v=x; return v+1; }
static inline long arch(unsigned long op,unsigned long arg) {
 long ret; __asm__ volatile("syscall" : "=a"(ret) : "0"(SYS_arch_prctl), "D"(op), "S"(arg) : "rcx","r11","memory"); return ret;
}
int main(void) {
 long enabled=arch(0x5001,1); if(enabled) { printf("enable_result=%ld\n",enabled); return 2; }
 unsigned long status=0; long queried=arch(0x5005,(unsigned long)&status);
 int value=nested(nested(40)); long disabled=arch(0x5002,1);
 printf("enable=%ld status_result=%ld status=%lu nested_return=%d disable=%ld\n",enabled,queried,status,value,disabled);
 return queried || status!=1 || value!=42 || disabled;
}
