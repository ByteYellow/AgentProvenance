# AgentProvenance v0.10.1 x86 验收

分支：`fix/v0.10.1-pr34-integration`  
源码：`4828cce10f0b53630d0a298affc760d5b1d6682c`  
构建工具：Go 1.23.0，目标 `linux/amd64`，`CGO_ENABLED=0`。

本包用于维护者的独立 x86 验收，尚未在 x86 执行。对应 ARM64 原生采集矩阵已在 Ubuntu 6.8.0-142-generic 通过。
不要合并 main、关闭 PR #34、打标签、发版或部署 Pages；结果回传后由维护者确认。

## 准备

- 一台可丢弃测试数据的 x86_64 Linux 主机，内核开放 eBPF/uprobe，`/sys/kernel/btf/vmlinux` 可读。
- root 或 sudo 权限。普通无特权容器通常无法完成原生探针验收。
- Bash、`cc`、`ldd`、OpenSSL 3 及其开发头文件、`sha256sum`。
- Go 1.23.x，用于在该主机编译 Go TLS 并发测试客户端。记录实际版本。

Ubuntu/Debian 缺少 C/OpenSSL 依赖时，可由维护者安装 `build-essential libssl-dev`。
脚本不自动安装依赖，不读取项目凭据，不访问 LLM 服务。请求发给测试启动的本地 HTTPS 服务。
测试会临时加载探针，并在 `/usr/lib` 建立独立临时库目录，结束时清理。

## 执行

先解压并进入本目录，再运行：

```sh
sha256sum -c SHA256SUMS
sudo bash ./run-x86.sh
```

运行脚本会顺序执行：

1. 原生 syscall 结果及 AppArmor/seccomp 状态读取。
2. OpenSSL 生命周期、读返回、32 路并发；4095/4096/4097/8192/1048577 字节边界、`SSL_write` 与 `_ex`；真实 ring 丢失。
3. 自动发现、显式库、禁用自动发现、延迟库、系统库、并发、inode 复用、新 Go 可执行文件，共八类短命 TLS 场景。
4. x86 Go TLS Read 并发与栈增长。

每组保留独立日志和退出码。出现 SKIP 时脚本不会记为整组通过；依赖或权限不足标为 BLOCKED。
不要放大时间窗口、提高缓冲上限或删除失败用例来通过验收。

## 回传

回传新生成的 `results-*/` 目录，包括：

- `environment.log`、`source.txt`、`checksums.log`；
- 三组测试日志；
- `summary.tsv` 中每组退出码和 PASS/FAIL/BLOCKED 状态。

短命发现日志已经记录首请求捕获、attach 延迟、CPU、扫描次数。保留全部数字，不只摘取 PASS。
若需检查本次之外的 CLI/daemon 业务路径，可在同一 SHA 检出仓库后运行原有回归；本包的 `agentprov` 可用于复核版本与手工任务。

## 已完成的本地交付

中英文 README、迁移说明、使用文档、CHANGELOG、发行说明草稿及在线 Demo 的嵌入文档已经更新到功能分支。
在线部署留待维护者审核。真实 DeepSeek 的前后两次运行、签名回环、页面搜索/对比和离线 ZIP 验收单独记录，未替换历史公开 Demo 原包。
