#!/usr/bin/env bash
set -uo pipefail
cd -- "$(dirname -- "$0")" || exit 2
out="results-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$out" || exit 2
printf '%s\n' '4828cce10f0b53630d0a298affc760d5b1d6682c' > "$out/source.txt"
printf 'check\texit_code\tstatus\n' > "$out/summary.tsv"
{
  date -u
  uname -a
  cat /etc/os-release
  id
  go version
  cc --version
  openssl version -a
  ./agentprov --version
} > "$out/environment.log" 2>&1
blocked=0
if [[ "$(uname -s)" != Linux || "$(uname -m)" != x86_64 || "$EUID" != 0 || ! -r /sys/kernel/btf/vmlinux ]]; then
  printf 'Requires x86_64 Linux, root, and readable kernel BTF.\n' >> "$out/environment.log"
  blocked=1
fi
for tool in cc ldd go openssl sha256sum; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    printf 'Missing dependency: %s\n' "$tool" >> "$out/environment.log"
    blocked=1
  fi
done
if [[ "$blocked" != 0 ]]; then
  printf 'preflight\t2\tBLOCKED\n' >> "$out/summary.tsv"
  printf 'BLOCKED: see %s\n' "$out/environment.log"
  exit 2
fi
if ! sha256sum -c SHA256SUMS > "$out/checksums.log" 2>&1; then
  printf 'checksums\t1\tFAIL\n' >> "$out/summary.tsv"
  exit 1
fi
failed=0
run_check() {
  local name="$1" rc status
  shift
  printf 'Running %s...\n' "$name"
  "$@" > "$out/$name.log" 2>&1
  rc=$?
  status=PASS
  if [[ "$rc" != 0 ]]; then
    status=FAIL
    failed=1
  elif grep -q -- '--- SKIP:' "$out/$name.log"; then
    status=BLOCKED
    failed=1
  elif ! grep -q -- '--- PASS:' "$out/$name.log"; then
    status=FAIL
    failed=1
  fi
  printf '%s\t%s\t%s\n' "$name" "$rc" "$status" >> "$out/summary.tsv"
}
run_check runtime env AGENTPROV_LIVE_OUTCOMES=1 AGENTPROV_ACCESS_STATE_LIVE=1 \
  ./sensor.test -test.run '^(TestLiveSyscallOutcomes|TestLiveSensorAccessState)$' -test.v -test.timeout=10m
run_check openssl-discovery env AGENTPROV_LIVE_OPENSSL=1 AGENTPROV_LIVE_TLS_CLIENT="$PWD/tls-client" \
  ./sensor.test -test.run '^(TestLiveOpenSSL|TestLiveTLSDiscoveryShortClient|TestTLSMessageMap)' -test.v -test.timeout=10m
run_check go-tls-read env AGENTPROV_LIVE_GOTLS=1 \
  ./sensor.test -test.run '^TestLiveGoTLSReadConcurrentStackGrowth$' -test.v -test.timeout=10m
cat "$out/summary.tsv"
printf 'Return this directory: %s/%s\n' "$PWD" "$out"
exit "$failed"
